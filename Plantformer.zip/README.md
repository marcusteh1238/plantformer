# Plantformer

Platformer - with plants

# Installation Instructions

1. Download GameMaker Studio 2
2. Follow instructions [here](https://help.yoyogames.com/hc/en-us/articles/360008803978-Setting-Up-And-Using-Source-Control)
3. Clone and done!
